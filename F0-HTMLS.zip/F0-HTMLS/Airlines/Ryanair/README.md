This one emulates a portal for a Ryanair "Free Hotspot" using EvilPortal on your Flipper Zero.
Not that anything is free at Ryanair but who cares.
!!FOR EDUCATIONAL USES ONLY!!
The HTML in the "WithForgotCredentials" file contains a "forgot credentials" button on the user side to make it look more realistic. This button only shows a message inviting them to go on their provider's app if they forgot their login/password.
Happy flippin'
![Ryanair Portal](https://zupimages.net/up/23/31/2vxa.png)
