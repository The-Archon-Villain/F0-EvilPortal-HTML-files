# !!FOR EDUCATIONAL USES ONLY!!
This one **emulates a portal for a Best Western "Free Hotspot"** using EvilPortal on your Flipper Zero.

The **HTML in the *"WithForgotCredentials"* file** contains a **"forgot credentials" button on the user side to make it look more realistic**. This button only shows a message inviting them to go on their provider's app if they forgot their login/password.
## Happy flippin'


![Best Western Hotels WiFi](https://zupimages.net/up/23/31/x35v.png)
